from django.core.management.base import BaseCommand
from core.chat_handler import start , reply
from core.utils import customer_id_generator


from telegram.ext.updater import Updater
from telegram.update import Update
from telegram.ext.callbackcontext import CallbackContext
from telegram.ext.commandhandler import CommandHandler
from telegram.ext.messagehandler import MessageHandler
from telegram.ext.filters import Filters





class Command(BaseCommand):
    help = 'Make a conversation with bot'

    def handle(self, *args, **kwargs):
        customer_id = customer_id_generator()
        updater = Updater("5182180094:AAFgoiXj51x9h70uNQMvfN5cLCXHNVD-5nc",
            use_context=True)

        dp = updater.dispatcher
        dp.add_handler(CommandHandler('start', start))
        dp.add_handler(MessageHandler(Filters.text, reply,pass_user_data=True))
        updater.start_polling()
        updater.idle()
